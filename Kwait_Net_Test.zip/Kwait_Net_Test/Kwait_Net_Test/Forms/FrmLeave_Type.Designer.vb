﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmLeave_Type
    Inherits System.Windows.Forms.Form

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Label1 = New Label()
        txtLeaveTypeName = New TextBox()
        btnAdd = New Button()
        btnUpdate = New Button()
        btnDelete = New Button()
        dgvLeaveTypes = New DataGridView()
        CType(dgvLeaveTypes, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(12, 33)
        Label1.Name = "Label1"
        Label1.Size = New Size(146, 19)
        Label1.TabIndex = 0
        Label1.Text = "Leave Type Name"
        ' 
        ' txtLeaveTypeName
        ' 
        txtLeaveTypeName.Location = New Point(174, 30)
        txtLeaveTypeName.Name = "txtLeaveTypeName"
        txtLeaveTypeName.Size = New Size(200, 27)
        txtLeaveTypeName.TabIndex = 1
        ' 
        ' btnAdd
        ' 
        btnAdd.Location = New Point(380, 27)
        btnAdd.Name = "btnAdd"
        btnAdd.Size = New Size(100, 30)
        btnAdd.TabIndex = 2
        btnAdd.Text = "Add"
        ' 
        ' btnUpdate
        ' 
        btnUpdate.Location = New Point(380, 67)
        btnUpdate.Name = "btnUpdate"
        btnUpdate.Size = New Size(100, 30)
        btnUpdate.TabIndex = 3
        btnUpdate.Text = "Update"
        ' 
        ' btnDelete
        ' 
        btnDelete.Location = New Point(380, 107)
        btnDelete.Name = "btnDelete"
        btnDelete.Size = New Size(100, 30)
        btnDelete.TabIndex = 4
        btnDelete.Text = "Delete"
        ' 
        ' dgvLeaveTypes
        ' 
        dgvLeaveTypes.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        dgvLeaveTypes.ColumnHeadersHeight = 29
        dgvLeaveTypes.Location = New Point(30, 150)
        dgvLeaveTypes.MultiSelect = False
        dgvLeaveTypes.Name = "dgvLeaveTypes"
        dgvLeaveTypes.ReadOnly = True
        dgvLeaveTypes.RowHeadersWidth = 51
        dgvLeaveTypes.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgvLeaveTypes.Size = New Size(450, 250)
        dgvLeaveTypes.TabIndex = 5
        ' 
        ' FrmLeave_Type
        ' 
        BackColor = Color.FromArgb(CByte(243), CByte(240), CByte(240))
        ClientSize = New Size(520, 420)
        Controls.Add(Label1)
        Controls.Add(txtLeaveTypeName)
        Controls.Add(btnAdd)
        Controls.Add(btnUpdate)
        Controls.Add(btnDelete)
        Controls.Add(dgvLeaveTypes)
        Font = New Font("Arial", 10F, FontStyle.Bold)
        Name = "FrmLeave_Type"
        Text = "Leave Types"
        CType(dgvLeaveTypes, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtLeaveTypeName As TextBox
    Friend WithEvents btnAdd As Button
    Friend WithEvents btnUpdate As Button
    Friend WithEvents btnDelete As Button
    Friend WithEvents dgvLeaveTypes As DataGridView
End Class
