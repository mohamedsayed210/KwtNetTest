﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmMainMDI
    Inherits System.Windows.Forms.Form

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmMainMDI))
        MenuStrip = New MenuStrip()
        FileMenu = New ToolStripMenuItem()
        DepartmnetToolStripMenuItem = New ToolStripMenuItem()
        PositionsToolStripMenuItem = New ToolStripMenuItem()
        EmployeesMenu = New ToolStripMenuItem()
        LeaveTypesMenu = New ToolStripMenuItem()
        ExitToolStripMenuItem = New ToolStripMenuItem()
        OperationToolStripMenuItem = New ToolStripMenuItem()
        LeavsToolStripMenuItem = New ToolStripMenuItem()
        LanguageMenu = New ToolStripMenuItem()
        EnglishMenu = New ToolStripMenuItem()
        ArabicMenu = New ToolStripMenuItem()
        StatusStrip = New StatusStrip()
        ToolStripStatusLabel = New ToolStripStatusLabel()
        MenuStrip.SuspendLayout()
        StatusStrip.SuspendLayout()
        SuspendLayout()
        ' 
        ' MenuStrip
        ' 
        MenuStrip.ImageScalingSize = New Size(20, 20)
        MenuStrip.Items.AddRange(New ToolStripItem() {FileMenu, OperationToolStripMenuItem, LanguageMenu})
        MenuStrip.Location = New Point(0, 0)
        MenuStrip.Name = "MenuStrip"
        MenuStrip.Size = New Size(900, 28)
        MenuStrip.TabIndex = 0
        MenuStrip.Text = "MenuStrip"
        ' 
        ' FileMenu
        ' 
        FileMenu.DropDownItems.AddRange(New ToolStripItem() {DepartmnetToolStripMenuItem, PositionsToolStripMenuItem, EmployeesMenu, LeaveTypesMenu, ExitToolStripMenuItem})
        FileMenu.Name = "FileMenu"
        FileMenu.Size = New Size(93, 24)
        FileMenu.Text = "Basic Data"
        ' 
        ' DepartmnetToolStripMenuItem
        ' 
        DepartmnetToolStripMenuItem.Name = "DepartmnetToolStripMenuItem"
        DepartmnetToolStripMenuItem.Size = New Size(172, 26)
        DepartmnetToolStripMenuItem.Text = "Departmnet"
        ' 
        ' PositionsToolStripMenuItem
        ' 
        PositionsToolStripMenuItem.Name = "PositionsToolStripMenuItem"
        PositionsToolStripMenuItem.Size = New Size(172, 26)
        PositionsToolStripMenuItem.Text = "Positions"
        ' 
        ' EmployeesMenu
        ' 
        EmployeesMenu.Name = "EmployeesMenu"
        EmployeesMenu.Size = New Size(172, 26)
        EmployeesMenu.Text = "Employees"
        ' 
        ' LeaveTypesMenu
        ' 
        LeaveTypesMenu.Name = "LeaveTypesMenu"
        LeaveTypesMenu.Size = New Size(172, 26)
        LeaveTypesMenu.Text = "Leaves Type"
        ' 
        ' ExitToolStripMenuItem
        ' 
        ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        ExitToolStripMenuItem.Size = New Size(172, 26)
        ExitToolStripMenuItem.Text = "E&xit"
        ' 
        ' OperationToolStripMenuItem
        ' 
        OperationToolStripMenuItem.DropDownItems.AddRange(New ToolStripItem() {LeavsToolStripMenuItem})
        OperationToolStripMenuItem.Name = "OperationToolStripMenuItem"
        OperationToolStripMenuItem.Size = New Size(90, 24)
        OperationToolStripMenuItem.Text = "Operation"
        ' 
        ' LeavsToolStripMenuItem
        ' 
        LeavsToolStripMenuItem.Name = "LeavsToolStripMenuItem"
        LeavsToolStripMenuItem.Size = New Size(128, 26)
        LeavsToolStripMenuItem.Text = "Leavs"
        ' 
        ' LanguageMenu
        ' 
        LanguageMenu.DropDownItems.AddRange(New ToolStripItem() {EnglishMenu, ArabicMenu})
        LanguageMenu.Name = "LanguageMenu"
        LanguageMenu.Size = New Size(88, 24)
        LanguageMenu.Text = "&Language"
        ' 
        ' EnglishMenu
        ' 
        EnglishMenu.Name = "EnglishMenu"
        EnglishMenu.Size = New Size(139, 26)
        EnglishMenu.Text = "English"
        ' 
        ' ArabicMenu
        ' 
        ArabicMenu.Name = "ArabicMenu"
        ArabicMenu.Size = New Size(139, 26)
        ArabicMenu.Text = "Arabic"
        ' 
        ' StatusStrip
        ' 
        StatusStrip.ImageScalingSize = New Size(20, 20)
        StatusStrip.Items.AddRange(New ToolStripItem() {ToolStripStatusLabel})
        StatusStrip.Location = New Point(0, 600)
        StatusStrip.Name = "StatusStrip"
        StatusStrip.Size = New Size(900, 26)
        StatusStrip.TabIndex = 1
        StatusStrip.Text = "StatusStrip"
        ' 
        ' ToolStripStatusLabel
        ' 
        ToolStripStatusLabel.Name = "ToolStripStatusLabel"
        ToolStripStatusLabel.Size = New Size(50, 20)
        ToolStripStatusLabel.Text = "Ready"
        ' 
        ' FrmMainMDI
        ' 
        BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), Image)
        BackgroundImageLayout = ImageLayout.Stretch
        ClientSize = New Size(900, 626)
        Controls.Add(StatusStrip)
        Controls.Add(MenuStrip)
        IsMdiContainer = True
        MainMenuStrip = MenuStrip
        Name = "FrmMainMDI"
        Text = "Employee Leave System"
        WindowState = FormWindowState.Maximized
        MenuStrip.ResumeLayout(False)
        MenuStrip.PerformLayout()
        StatusStrip.ResumeLayout(False)
        StatusStrip.PerformLayout()
        ResumeLayout(False)
        PerformLayout()

    End Sub

    Friend WithEvents MenuStrip As MenuStrip
    Friend WithEvents FileMenu As ToolStripMenuItem
    Friend WithEvents EmployeesMenu As ToolStripMenuItem
    Friend WithEvents LeaveTypesMenu As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LanguageMenu As ToolStripMenuItem
    Friend WithEvents EnglishMenu As ToolStripMenuItem
    Friend WithEvents ArabicMenu As ToolStripMenuItem
    Friend WithEvents StatusStrip As StatusStrip
    Friend WithEvents ToolStripStatusLabel As ToolStripStatusLabel
    Friend WithEvents OperationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LeavsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DepartmnetToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PositionsToolStripMenuItem As ToolStripMenuItem
End Class
