﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmEmployee
    Inherits System.Windows.Forms.Form

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As DataGridViewCellStyle = New DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As DataGridViewCellStyle = New DataGridViewCellStyle()
        lblName = New Label()
        txtName = New TextBox()
        lblDept = New Label()
        cmbDept = New ComboBox()
        lblPosition = New Label()
        cmbPosition = New ComboBox()
        lblHireDate = New Label()
        dtpHireDate = New DateTimePicker()
        btnSave = New Button()
        btnDelete = New Button()
        dgvEmployees = New DataGridView()
        Label1 = New Label()
        txtSalary = New TextBox()
        Label2 = New Label()
        txtPhone = New TextBox()
        txtAddress = New TextBox()
        Label3 = New Label()
        CType(dgvEmployees, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' lblName
        ' 
        lblName.AutoSize = True
        lblName.Location = New Point(20, 20)
        lblName.Name = "lblName"
        lblName.Size = New Size(59, 19)
        lblName.TabIndex = 0
        lblName.Text = "Name:"
        ' 
        ' txtName
        ' 
        txtName.Location = New Point(100, 17)
        txtName.Name = "txtName"
        txtName.Size = New Size(390, 27)
        txtName.TabIndex = 1
        ' 
        ' lblDept
        ' 
        lblDept.AutoSize = True
        lblDept.Location = New Point(383, 73)
        lblDept.Name = "lblDept"
        lblDept.Size = New Size(107, 19)
        lblDept.TabIndex = 2
        lblDept.Text = "Department:"
        ' 
        ' cmbDept
        ' 
        cmbDept.DropDownStyle = ComboBoxStyle.DropDownList
        cmbDept.Location = New Point(496, 70)
        cmbDept.Name = "cmbDept"
        cmbDept.Size = New Size(274, 27)
        cmbDept.TabIndex = 3
        ' 
        ' lblPosition
        ' 
        lblPosition.AutoSize = True
        lblPosition.Location = New Point(20, 73)
        lblPosition.Name = "lblPosition"
        lblPosition.Size = New Size(79, 19)
        lblPosition.TabIndex = 4
        lblPosition.Text = "Position:"
        ' 
        ' cmbPosition
        ' 
        cmbPosition.DropDownStyle = ComboBoxStyle.DropDownList
        cmbPosition.Location = New Point(100, 73)
        cmbPosition.Name = "cmbPosition"
        cmbPosition.Size = New Size(262, 27)
        cmbPosition.TabIndex = 5
        ' 
        ' lblHireDate
        ' 
        lblHireDate.AutoSize = True
        lblHireDate.Location = New Point(383, 125)
        lblHireDate.Name = "lblHireDate"
        lblHireDate.Size = New Size(88, 19)
        lblHireDate.TabIndex = 6
        lblHireDate.Text = "Hire Date:"
        ' 
        ' dtpHireDate
        ' 
        dtpHireDate.Format = DateTimePickerFormat.Short
        dtpHireDate.Location = New Point(496, 121)
        dtpHireDate.Name = "dtpHireDate"
        dtpHireDate.Size = New Size(150, 27)
        dtpHireDate.TabIndex = 7
        ' 
        ' btnSave
        ' 
        btnSave.Location = New Point(166, 212)
        btnSave.Name = "btnSave"
        btnSave.Size = New Size(90, 35)
        btnSave.TabIndex = 8
        btnSave.Text = "Save"
        ' 
        ' btnDelete
        ' 
        btnDelete.Location = New Point(385, 212)
        btnDelete.Name = "btnDelete"
        btnDelete.Size = New Size(90, 35)
        btnDelete.TabIndex = 9
        btnDelete.Text = "Delete"
        ' 
        ' dgvEmployees
        ' 
        dgvEmployees.AllowUserToAddRows = False
        dgvEmployees.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = Color.FromArgb(CByte(238), CByte(239), CByte(249))
        dgvEmployees.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        dgvEmployees.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        DataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = Color.FromArgb(CByte(207), CByte(195), CByte(192))
        DataGridViewCellStyle2.Font = New Font("Arial", 10F, FontStyle.Bold)
        DataGridViewCellStyle2.ForeColor = SystemColors.WindowText
        DataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = Color.White
        DataGridViewCellStyle2.WrapMode = DataGridViewTriState.True
        dgvEmployees.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        dgvEmployees.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvEmployees.Location = New Point(12, 262)
        dgvEmployees.MultiSelect = False
        dgvEmployees.Name = "dgvEmployees"
        dgvEmployees.ReadOnly = True
        dgvEmployees.RowHeadersWidth = 51
        dgvEmployees.RowTemplate.Height = 25
        dgvEmployees.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgvEmployees.Size = New Size(750, 188)
        dgvEmployees.TabIndex = 10
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(20, 121)
        Label1.Name = "Label1"
        Label1.Size = New Size(69, 19)
        Label1.TabIndex = 14
        Label1.Text = "Salary :"
        ' 
        ' txtSalary
        ' 
        txtSalary.Location = New Point(106, 118)
        txtSalary.Name = "txtSalary"
        txtSalary.Size = New Size(125, 27)
        txtSalary.TabIndex = 15
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(496, 24)
        Label2.Name = "Label2"
        Label2.Size = New Size(79, 19)
        Label2.TabIndex = 16
        Label2.Text = "Phone #:"
        ' 
        ' txtPhone
        ' 
        txtPhone.Location = New Point(570, 21)
        txtPhone.Name = "txtPhone"
        txtPhone.Size = New Size(200, 27)
        txtPhone.TabIndex = 17
        ' 
        ' txtAddress
        ' 
        txtAddress.Location = New Point(100, 169)
        txtAddress.Name = "txtAddress"
        txtAddress.Size = New Size(662, 27)
        txtAddress.TabIndex = 18
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(20, 172)
        Label3.Name = "Label3"
        Label3.Size = New Size(74, 19)
        Label3.TabIndex = 19
        Label3.Text = "Address"
        ' 
        ' FrmEmployee
        ' 
        BackColor = Color.FromArgb(CByte(243), CByte(240), CByte(240))
        ClientSize = New Size(800, 495)
        Controls.Add(Label3)
        Controls.Add(txtAddress)
        Controls.Add(txtPhone)
        Controls.Add(Label2)
        Controls.Add(txtSalary)
        Controls.Add(Label1)
        Controls.Add(lblName)
        Controls.Add(txtName)
        Controls.Add(lblDept)
        Controls.Add(cmbDept)
        Controls.Add(lblPosition)
        Controls.Add(cmbPosition)
        Controls.Add(lblHireDate)
        Controls.Add(dtpHireDate)
        Controls.Add(btnSave)
        Controls.Add(btnDelete)
        Controls.Add(dgvEmployees)
        Font = New Font("Arial", 10F, FontStyle.Bold)
        FormBorderStyle = FormBorderStyle.FixedToolWindow
        Name = "FrmEmployee"
        Text = "Employee Management"
        CType(dgvEmployees, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()

    End Sub

    Friend WithEvents lblName As Label
    Friend WithEvents txtName As TextBox
    Friend WithEvents lblDept As Label
    Friend WithEvents cmbDept As ComboBox
    Friend WithEvents lblPosition As Label
    Friend WithEvents cmbPosition As ComboBox
    Friend WithEvents lblHireDate As Label
    Friend WithEvents dtpHireDate As DateTimePicker
    Friend WithEvents btnSave As Button
    Friend WithEvents btnDelete As Button
    Friend WithEvents dgvEmployees As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents txtSalary As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtPhone As TextBox
    Friend WithEvents txtAddress As TextBox
    Friend WithEvents Label3 As Label

End Class
