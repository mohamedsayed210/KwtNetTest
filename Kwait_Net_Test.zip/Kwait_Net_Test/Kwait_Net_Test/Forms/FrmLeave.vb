﻿Public Class FrmLeave
    Private ReadOnly _employeeService As IEmployeeService
    Private ReadOnly _leaveService As ILeaveService
    Private ReadOnly _leaveTypeService As ILeaveTypeService
    Private currentEmployeeId As Integer = 0
    Private currentLeaveId As Integer = 0
    Private EmployeeMap As New Dictionary(Of String, Integer)
    Public Sub New()
        InitializeComponent()
        _employeeService = New EmployeeService()
        _leaveService = New LeaveService()
        _leaveTypeService = New LeaveTypeService()

    End Sub
    Private Sub LoadLeaveTypes()
        cmbLeaveType.DataSource = _leaveTypeService.GetAll()
        cmbLeaveType.DisplayMember = "LeaveType_Name"
        cmbLeaveType.ValueMember = "LeaveTypeId"
        cmbLeaveType.SelectedIndex = -1
    End Sub

    Private Sub FrmLeave_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadLeaveTypes()
        SetupEmployeeAutocomplete()
    End Sub

    Private Sub btnLoad_Click(sender As Object, e As EventArgs) Handles btnLoad.Click
        If Not Integer.TryParse(txtEmpNo.Text, currentEmployeeId) Then
            MessageHelper.ShowError("Invalid employee number.")
            Return
        End If

        Dim emp = _employeeService.GetById(currentEmployeeId)
        If emp Is Nothing Then
            MessageHelper.ShowError("Employee not found.")
            Return
        End If

        LoadLeaves()

    End Sub

    Private Sub LoadLeaves()
        dgvLeaves.DataSource = _leaveService.GetByEmployee(currentEmployeeId)

        If dgvLeaves.Columns.Contains("LeaveID") Then
            dgvLeaves.Columns("LeaveID").Visible = False
        End If
        dgvLeaves.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells)

    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If currentEmployeeId = 0 Then
            MessageHelper.ShowError("Load employee first.")
            Return
        End If
        If cmbLeaveType.SelectedIndex = -1 OrElse cmbLeaveType.SelectedValue Is Nothing Then
            MessageHelper.ShowError("Please select a leave type.")
            Return
        End If
        If dtpEndDate.Value.Date < dtpStartDate.Value.Date Then
            MessageHelper.ShowError("End date must be greater than or equal to start date.")
            Return
        End If
        Dim leave As New Leaves With {
        .EmployeeID = currentEmployeeId,
        .LeaveType_ID = CInt(cmbLeaveType.SelectedValue),
        .StartDate = dtpStartDate.Value.Date,
        .EndDate = dtpEndDate.Value.Date,
        .Notes = txtNotes.Text.Trim()
    }
        If currentLeaveId = 0 Then
            _leaveService.Add(leave)

            MessageHelper.ShowSuccess("Leaves added successfully.")
        Else
            leave.LeaveID = currentLeaveId
            _leaveService.Update(leave)
            MessageHelper.ShowSuccess("Leaves updated successfully.")
        End If


        LoadLeaves()
        FormHelper.ClearTextBoxes(Me)
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If currentLeaveId = 0 Then
            MessageHelper.ShowWarning("Select a leave to delete.")
            Return
        End If

        _leaveService.Delete(currentLeaveId)
        MessageHelper.ShowSuccess("Leave deleted.")
        LoadLeaves()
        currentLeaveId = 0
    End Sub
    Private Sub dgvLeaves_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvLeaves.CellClick


        Dim selectedRow = dgvLeaves.CurrentRow

        txtEmpNo.Text = selectedRow.Cells("EmployeeName").Value.ToString()
        cmbLeaveType.SelectedIndex = cmbLeaveType.FindStringExact(selectedRow.Cells("LeaveTypeName").Value.ToString())
        dtpStartDate.Value = CDate(selectedRow.Cells("StartDate").Value)
        dtpEndDate.Value = CDate(selectedRow.Cells("EndDate").Value)
        txtNotes.Text = If(selectedRow.Cells("Notes").Value IsNot Nothing, selectedRow.Cells("Notes").Value.ToString(), "")

        txtEmpName.Text = selectedRow.Cells("EmployeeName").Value.ToString()
        currentLeaveId = CInt(selectedRow.Cells("LeaveID").Value)
    End Sub
    Private Sub SetupEmployeeAutocomplete()


        Dim employees = _employeeService.GetEmployees().Select(Function(e) New With {
                Key .ID = e.EmployeeID,
                Key .Name = e.FullName
            }).ToList()


        EmployeeMap.Clear()


        For Each emp In employees
            EmployeeMap(emp.Name) = emp.ID
        Next


        Dim source As New AutoCompleteStringCollection()
        source.AddRange(EmployeeMap.Keys.ToArray())

        txtEmpNo.AutoCompleteMode = AutoCompleteMode.SuggestAppend
        txtEmpNo.AutoCompleteSource = AutoCompleteSource.CustomSource
        txtEmpNo.AutoCompleteCustomSource = source

    End Sub
    Private Sub txtEmpNo_Leave(sender As Object, e As EventArgs) Handles txtEmpNo.Leave
        Dim name = txtEmpNo.Text.Trim()

        If EmployeeMap.ContainsKey(name) Then
            Dim empId = EmployeeMap(name)
            currentEmployeeId = empId
            LoadEmployeeDetails(empId)

            LoadLeaves()
        Else
            MessageBox.Show("Employee not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub

    Private Sub LoadEmployeeDetails(empId As Integer)

        Dim emp = _employeeService.GetById(empId)
        If emp IsNot Nothing Then

            txtEmpName.Text = emp.FullName

        End If

    End Sub

    Private Sub txtEmpNo_KeyDown(sender As Object, e As KeyEventArgs) Handles txtEmpNo.KeyDown
        If e.KeyCode = Keys.Enter Then
            txtEmpNo_Leave(sender, EventArgs.Empty)
        End If

    End Sub
End Class