﻿Public Class FrmPosition
    Private currentPositionId As Integer = 0
    Private ReadOnly _positionService As IPositionService
    Public Sub New()
        InitializeComponent()

        _positionService = New PositionService()
    End Sub
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        If txtPositionName.Text.Trim() = String.Empty Then
            MessageBox.Show("Please enter a position name.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Dim newPosition As New Position() With {
                .Position_Name = txtPositionName.Text.Trim()
            }

        _positionService.Add(newPosition)
        MessageHelper.ShowSuccess("Position added successfully.")
        LoadPositions()
        ClearInputs()

    End Sub

    Private Sub ClearInputs()
        FormHelper.ClearTextBoxes(Me)
    End Sub

    Private Sub LoadPositions()

        dgvPositions.DataSource = _positionService.GetAll()
        If dgvPositions.Columns.Contains("Employees") Then
            dgvPositions.Columns("Employees").Visible = False
        End If
        dgvPositions.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells)

    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If currentPositionId = 0 Then
            MessageBox.Show("Please select a position to update.", "Selection Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If
        If currentPositionId = 0 Then
            MessageHelper.ShowWarning("Please select a position to update.")
            Return
        End If

        Dim position = _positionService.GetById(currentPositionId)

        If position Is Nothing Then
            MessageHelper.ShowError("Position not found.")
            Return
        End If

        position.Position_Name = txtPositionName.Text.Trim()

        _positionService.Update(position)

        MessageHelper.ShowSuccess("Position updated successfully.")

        LoadPositions()
        ClearInputs()
        currentPositionId = 0
    End Sub

    Private Sub FrmPosition_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadPositions()
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If currentPositionId = 0 Then
            MessageBox.Show("Select a position from the grid to delete.")
            Return
        End If

        Dim position = _positionService.GetById(currentPositionId)

        If position Is Nothing Then
            MessageHelper.ShowError("Position not found.")
            Return
        End If
        _positionService.Delete(currentPositionId)
        ClearInputs()
        LoadPositions()
    End Sub
    Private Sub dgvPositions_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvPositions.CellClick
        If e.RowIndex >= 0 Then
            Dim row = dgvPositions.Rows(e.RowIndex)
            currentPositionId = Convert.ToInt32(row.Cells("Position_ID").Value)
            txtPositionName.Text = row.Cells("Position_Name").Value.ToString()
        End If
    End Sub
End Class