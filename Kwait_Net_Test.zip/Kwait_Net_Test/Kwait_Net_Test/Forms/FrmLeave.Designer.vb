﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmLeave
    Inherits System.Windows.Forms.Form

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        lblEmpNo = New Label()
        txtEmpNo = New TextBox()
        btnLoad = New Button()
        dgvLeaves = New DataGridView()
        lblLeaveType = New Label()
        cmbLeaveType = New ComboBox()
        lblStartDate = New Label()
        dtpStartDate = New DateTimePicker()
        lblEndDate = New Label()
        dtpEndDate = New DateTimePicker()
        lblNotes = New Label()
        txtNotes = New TextBox()
        btnSave = New Button()
        btnDelete = New Button()
        lblName = New Label()
        txtEmpName = New TextBox()
        CType(dgvLeaves, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' lblEmpNo
        ' 
        lblEmpNo.AutoSize = True
        lblEmpNo.Location = New Point(20, 20)
        lblEmpNo.Name = "lblEmpNo"
        lblEmpNo.Size = New Size(102, 20)
        lblEmpNo.TabIndex = 0
        lblEmpNo.Text = "Employee No:"
        ' 
        ' txtEmpNo
        ' 
        txtEmpNo.Location = New Point(130, 13)
        txtEmpNo.Name = "txtEmpNo"
        txtEmpNo.Size = New Size(304, 27)
        txtEmpNo.TabIndex = 1
        ' 
        ' btnLoad
        ' 
        btnLoad.Location = New Point(440, 10)
        btnLoad.Name = "btnLoad"
        btnLoad.Size = New Size(80, 30)
        btnLoad.TabIndex = 2
        btnLoad.Text = "Load"
        ' 
        ' dgvLeaves
        ' 
        dgvLeaves.AllowUserToAddRows = False
        dgvLeaves.AllowUserToDeleteRows = False
        dgvLeaves.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        dgvLeaves.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvLeaves.Location = New Point(20, 236)
        dgvLeaves.MultiSelect = False
        dgvLeaves.Name = "dgvLeaves"
        dgvLeaves.ReadOnly = True
        dgvLeaves.RowHeadersWidth = 51
        dgvLeaves.RowTemplate.Height = 25
        dgvLeaves.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgvLeaves.Size = New Size(859, 200)
        dgvLeaves.TabIndex = 13
        ' 
        ' lblLeaveType
        ' 
        lblLeaveType.AutoSize = True
        lblLeaveType.Location = New Point(20, 131)
        lblLeaveType.Name = "lblLeaveType"
        lblLeaveType.Size = New Size(85, 20)
        lblLeaveType.TabIndex = 3
        lblLeaveType.Text = "Leave Type:"
        ' 
        ' cmbLeaveType
        ' 
        cmbLeaveType.DropDownStyle = ComboBoxStyle.DropDownList
        cmbLeaveType.Location = New Point(130, 131)
        cmbLeaveType.Name = "cmbLeaveType"
        cmbLeaveType.Size = New Size(150, 28)
        cmbLeaveType.TabIndex = 4
        ' 
        ' lblStartDate
        ' 
        lblStartDate.AutoSize = True
        lblStartDate.Location = New Point(20, 94)
        lblStartDate.Name = "lblStartDate"
        lblStartDate.Size = New Size(79, 20)
        lblStartDate.TabIndex = 5
        lblStartDate.Text = "Start Date:"
        ' 
        ' dtpStartDate
        ' 
        dtpStartDate.Format = DateTimePickerFormat.Short
        dtpStartDate.Location = New Point(130, 87)
        dtpStartDate.Name = "dtpStartDate"
        dtpStartDate.Size = New Size(120, 27)
        dtpStartDate.TabIndex = 6
        ' 
        ' lblEndDate
        ' 
        lblEndDate.AutoSize = True
        lblEndDate.Location = New Point(307, 92)
        lblEndDate.Name = "lblEndDate"
        lblEndDate.Size = New Size(73, 20)
        lblEndDate.TabIndex = 7
        lblEndDate.Text = "End Date:"
        ' 
        ' dtpEndDate
        ' 
        dtpEndDate.Format = DateTimePickerFormat.Short
        dtpEndDate.Location = New Point(400, 85)
        dtpEndDate.Name = "dtpEndDate"
        dtpEndDate.Size = New Size(150, 27)
        dtpEndDate.TabIndex = 8
        ' 
        ' lblNotes
        ' 
        lblNotes.AutoSize = True
        lblNotes.Location = New Point(329, 139)
        lblNotes.Name = "lblNotes"
        lblNotes.Size = New Size(51, 20)
        lblNotes.TabIndex = 9
        lblNotes.Text = "Notes:"
        ' 
        ' txtNotes
        ' 
        txtNotes.Location = New Point(400, 128)
        txtNotes.Name = "txtNotes"
        txtNotes.Size = New Size(388, 27)
        txtNotes.TabIndex = 10
        ' 
        ' btnSave
        ' 
        btnSave.Location = New Point(130, 174)
        btnSave.Name = "btnSave"
        btnSave.Size = New Size(90, 35)
        btnSave.TabIndex = 11
        btnSave.Text = "Save"
        ' 
        ' btnDelete
        ' 
        btnDelete.Location = New Point(400, 174)
        btnDelete.Name = "btnDelete"
        btnDelete.Size = New Size(90, 35)
        btnDelete.TabIndex = 12
        btnDelete.Text = "Delete"
        ' 
        ' lblName
        ' 
        lblName.AutoSize = True
        lblName.Location = New Point(20, 56)
        lblName.Name = "lblName"
        lblName.Size = New Size(52, 20)
        lblName.TabIndex = 14
        lblName.Text = "Name:"
        ' 
        ' txtEmpName
        ' 
        txtEmpName.Location = New Point(130, 53)
        txtEmpName.Name = "txtEmpName"
        txtEmpName.ReadOnly = True
        txtEmpName.Size = New Size(658, 27)
        txtEmpName.TabIndex = 15
        ' 
        ' FrmLeave
        ' 
        ClientSize = New Size(887, 476)
        Controls.Add(lblName)
        Controls.Add(txtEmpName)
        Controls.Add(lblEmpNo)
        Controls.Add(txtEmpNo)
        Controls.Add(btnLoad)
        Controls.Add(lblLeaveType)
        Controls.Add(cmbLeaveType)
        Controls.Add(lblStartDate)
        Controls.Add(dtpStartDate)
        Controls.Add(lblEndDate)
        Controls.Add(dtpEndDate)
        Controls.Add(lblNotes)
        Controls.Add(txtNotes)
        Controls.Add(btnSave)
        Controls.Add(btnDelete)
        Controls.Add(dgvLeaves)
        Name = "FrmLeave"
        Text = "Leave Management"
        CType(dgvLeaves, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    ' ---------------------------
    ' Controls
    ' ---------------------------
    Friend WithEvents lblEmpNo As Label
    Friend WithEvents txtEmpNo As TextBox
    Friend WithEvents btnLoad As Button
    Friend WithEvents dgvLeaves As DataGridView
    Friend WithEvents lblLeaveType As Label
    Friend WithEvents cmbLeaveType As ComboBox
    Friend WithEvents lblStartDate As Label
    Friend WithEvents dtpStartDate As DateTimePicker
    Friend WithEvents lblEndDate As Label
    Friend WithEvents dtpEndDate As DateTimePicker
    Friend WithEvents lblNotes As Label
    Friend WithEvents txtNotes As TextBox
    Friend WithEvents btnSave As Button
    Friend WithEvents btnDelete As Button
    Friend WithEvents lblName As Label
    Friend WithEvents txtEmpName As TextBox

End Class
