﻿Imports System.Windows.Forms
Public Class FrmMainMDI

    Private m_ChildFormNumber As Integer

    Private Sub ExitToolsStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub



    Private Sub EmployeesMenu_Click(sender As Object, e As EventArgs) Handles EmployeesMenu.Click
        For Each frm As Form In Me.MdiChildren
            If TypeOf frm Is FrmEmployee Then
                frm.Activate()
                Return
            End If
        Next

        Dim frmEmployee As New FrmEmployee()
        frmEmployee.MdiParent = Me
        frmEmployee.Show()
    End Sub

    Private Sub LeavesMenu_Click(sender As Object, e As EventArgs) Handles LeaveTypesMenu.Click
        Dim frmLeaveType As New FrmLeave_Type()
        frmLeaveType.MdiParent = Me
        frmLeaveType.Show()
    End Sub
    Private Sub CloseAllToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        For Each ChildForm In MdiChildren
            ChildForm.Close()
        Next
    End Sub

    Private Sub LeavsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LeavsToolStripMenuItem.Click
        For Each frm As Form In Me.MdiChildren
            If TypeOf frm Is FrmLeave Then
                frm.Activate()
                Return
            End If
        Next

        Dim frmLeave As New FrmLeave()
        frmLeave.MdiParent = Me
        frmLeave.Show()
    End Sub

    Private Sub DepartmnetToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DepartmnetToolStripMenuItem.Click
        Dim frmDeprtment As New FrmDepartment()
        FrmDepartment.MdiParent = Me
        FrmDepartment.Show()
    End Sub

    Private Sub PositionsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PositionsToolStripMenuItem.Click
        Dim frmPosition As New FrmPosition()
        frmPosition.MdiParent = Me
        frmPosition.Show()
    End Sub

    Private Sub FrmMainMDI_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Application.Exit()

    End Sub

    Private Sub FrmMainMDI_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing

        For Each child As Form In Me.MdiChildren
            child.Close()
        Next
    End Sub
End Class
