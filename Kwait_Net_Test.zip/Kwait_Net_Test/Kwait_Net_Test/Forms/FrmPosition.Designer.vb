﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmPosition
    Inherits System.Windows.Forms.Form

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Label1 = New Label()
        txtPositionName = New TextBox()
        btnAdd = New Button()
        btnUpdate = New Button()
        btnDelete = New Button()
        dgvPositions = New DataGridView()
        CType(dgvPositions, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(30, 30)
        Label1.Name = "Label1"
        Label1.Size = New Size(105, 20)
        Label1.TabIndex = 0
        Label1.Text = "Position Name"
        ' 
        ' txtPositionName
        ' 
        txtPositionName.Location = New Point(140, 27)
        txtPositionName.Name = "txtPositionName"
        txtPositionName.Size = New Size(200, 27)
        txtPositionName.TabIndex = 1
        ' 
        ' btnAdd
        ' 
        btnAdd.Location = New Point(360, 27)
        btnAdd.Name = "btnAdd"
        btnAdd.Size = New Size(100, 30)
        btnAdd.TabIndex = 2
        btnAdd.Text = "Add"
        ' 
        ' btnUpdate
        ' 
        btnUpdate.Location = New Point(360, 67)
        btnUpdate.Name = "btnUpdate"
        btnUpdate.Size = New Size(100, 30)
        btnUpdate.TabIndex = 3
        btnUpdate.Text = "Update"
        ' 
        ' btnDelete
        ' 
        btnDelete.Location = New Point(360, 107)
        btnDelete.Name = "btnDelete"
        btnDelete.Size = New Size(100, 30)
        btnDelete.TabIndex = 4
        btnDelete.Text = "Delete"
        ' 
        ' dgvPositions
        ' 
        dgvPositions.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        dgvPositions.ColumnHeadersHeight = 29
        dgvPositions.Location = New Point(30, 150)
        dgvPositions.MultiSelect = False
        dgvPositions.Name = "dgvPositions"
        dgvPositions.ReadOnly = True
        dgvPositions.RowHeadersWidth = 51
        dgvPositions.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgvPositions.Size = New Size(430, 250)
        dgvPositions.TabIndex = 5
        ' 
        ' FrmPosition
        ' 
        ClientSize = New Size(500, 470)
        Controls.Add(Label1)
        Controls.Add(txtPositionName)
        Controls.Add(btnAdd)
        Controls.Add(btnUpdate)
        Controls.Add(btnDelete)
        Controls.Add(dgvPositions)
        Name = "FrmPosition"
        Text = "Positions"
        CType(dgvPositions, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtPositionName As TextBox
    Friend WithEvents btnAdd As Button
    Friend WithEvents btnUpdate As Button
    Friend WithEvents btnDelete As Button
    Friend WithEvents dgvPositions As DataGridView
End Class
