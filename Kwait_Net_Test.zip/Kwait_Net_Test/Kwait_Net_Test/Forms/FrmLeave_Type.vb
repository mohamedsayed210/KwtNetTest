﻿Public Class FrmLeave_Type
    Private currentLeaveTypeId As Integer = 0
    Private _leaveTypeService As ILeaveTypeService
    Public Sub New()


        InitializeComponent()

        _leaveTypeService = New LeaveTypeService()
    End Sub
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        If txtLeaveTypeName.Text.Trim() = String.Empty Then
            MessageBox.Show("Please enter a leave type name.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Dim newLeaveType As New LeaveTypes() With {
                .LeaveType_Name = txtLeaveTypeName.Text.Trim()
            }
        _leaveTypeService.Add(newLeaveType)
        MessageHelper.ShowSuccess("Leave type added successfully.")

            LoadLeaveTypes()
            ClearInputs()

    End Sub

    Private Sub ClearInputs()
        FormHelper.ClearTextBoxes(Me)
    End Sub

    Private Sub LoadLeaveTypes()
        dgvLeaveTypes.DataSource = _leaveTypeService.GetAll()
        If dgvLeaveTypes.Columns.Contains("leaves") Then
            dgvLeaveTypes.Columns("leaves").Visible = False
        End If
        dgvLeaveTypes.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells)


    End Sub

    Private Sub FrmLeave_Type_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadLeaveTypes()
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If currentLeaveTypeId = 0 Then
            MessageBox.Show("Please select a leave type to update.", "Selection Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Dim leaveTypeToUpdate = _leaveTypeService.GetById(currentLeaveTypeId)
        If leaveTypeToUpdate IsNot Nothing Then
            leaveTypeToUpdate.LeaveType_Name = txtLeaveTypeName.Text.Trim()
            _leaveTypeService.Update(leaveTypeToUpdate)
            MessageHelper.ShowSuccess("Leave type added successfully.")

                LoadLeaveTypes()
                ClearInputs()
                currentLeaveTypeId = 0
            Else
                MessageBox.Show("Leave type not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If currentLeaveTypeId = 0 Then
            MessageBox.Show("Please select a leave type to delete.", "Selection Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Dim leaveTypeToDelete = _leaveTypeService.GetById(currentLeaveTypeId)
        If leaveTypeToDelete IsNot Nothing Then
            _leaveTypeService.Delete(currentLeaveTypeId)
            MessageBox.Show("Leave type deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                LoadLeaveTypes()
                ClearInputs()
                currentLeaveTypeId = 0
            Else
                MessageBox.Show("Leave type not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

    End Sub
    Private Sub dgvLeaveTypes_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvLeaveTypes.CellClick
        If e.RowIndex >= 0 Then
            Dim row = dgvLeaveTypes.Rows(e.RowIndex)
            currentLeaveTypeId = Convert.ToInt32(row.Cells("LeaveTypeId").Value)
            txtLeaveTypeName.Text = row.Cells("LeaveType_Name").Value.ToString()
        End If
    End Sub

End Class