﻿Imports System.Drawing.Printing
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class FrmEmployee
    Private ReadOnly _employeeService As IEmployeeService
    Private ReadOnly _departmentService As IDepartmentService
    Private ReadOnly _positionService As IPositionService
    Private selectedEmployeeId As Integer = 0
    Public Sub New()
        InitializeComponent()
        _employeeService = New EmployeeService()
        _departmentService = New DepartmentService()
        _positionService = New PositionService()
    End Sub
    Private Sub FrmEmployee_Load(sender As Object, e As EventArgs) _
        Handles MyBase.Load
        LoadDepartments()
        LoadPositions()
        LoadEmployees()
    End Sub
    Private Sub LoadDepartments()
        cmbDept.DataSource = _departmentService.GetAll()
        cmbDept.DisplayMember = "Depart_Name"
        cmbDept.ValueMember = "Depart_Id"
        cmbDept.SelectedIndex = -1
    End Sub

    Private Sub LoadPositions()
        cmbPosition.DataSource = _positionService.GetAll()
        cmbPosition.DisplayMember = "Position_Name"
        cmbPosition.ValueMember = "Position_ID"
        cmbPosition.SelectedIndex = -1
    End Sub
    Private Sub LoadEmployees()
        dgvEmployees.DataSource = _employeeService.GetEmployees()

        If dgvEmployees.Columns.Contains("Dep_Id") Then dgvEmployees.Columns("Dep_Id").Visible = False
        If dgvEmployees.Columns.Contains("Position_Id") Then dgvEmployees.Columns("Position_Id").Visible = False
        If dgvEmployees.Columns.Contains("leaves") Then
            dgvEmployees.Columns("leaves").Visible = False
        End If
        dgvEmployees.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells)

    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        'for add New  Or update existing employee
        If String.IsNullOrWhiteSpace(txtName.Text) Then
            MessageHelper.ShowWarning("Employee name is required.")
            Return
        End If

        Dim emp As New Employees With {
        .EmployeeID = selectedEmployeeId,
        .FullName = txtName.Text.Trim(),
        .HireDate = dtpHireDate.Value,
        .Dep_Id = CInt(cmbDept.SelectedValue),
        .Phone_Number = txtPhone.Text.Trim(),
        .Emp_Address = txtAddress.Text.Trim(),
        .Position_Id = CInt(cmbPosition.SelectedValue),
        .Salary = Convert.ToDecimal(txtSalary.Text)
    }

        If selectedEmployeeId = 0 Then
            _employeeService.Add(emp)
            MessageHelper.ShowSuccess("Employee added successfully.")
        Else
            _employeeService.Update(emp)
            MessageHelper.ShowSuccess("Employee updated successfully.")
        End If

        FormHelper.ClearTextBoxes(Me)
        LoadEmployees()
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If selectedEmployeeId = 0 Then
            MessageHelper.ShowWarning("Please select an employee.")
            Return
        End If

        _employeeService.Delete(selectedEmployeeId)
        MessageHelper.ShowSuccess("Employee deleted successfully.")

        FormHelper.ClearTextBoxes(Me)
        LoadEmployees()
    End Sub
    Private Sub dgvEmployees_CellClick(sender As Object, e As DataGridViewCellEventArgs) _
       Handles dgvEmployees.CellClick

        If e.RowIndex >= 0 Then
            Dim row = dgvEmployees.Rows(e.RowIndex)
            selectedEmployeeId = CInt(row.Cells("EmployeeID").Value)
            txtName.Text = row.Cells("FullName").Value.ToString()
            dtpHireDate.Value = CDate(row.Cells("HireDate").Value)
            cmbDept.SelectedValue = row.Cells("Dep_Id").Value
            cmbPosition.SelectedValue = row.Cells("Position_Id").Value
            txtSalary.Text = row.Cells("Salary").Value.ToString()
        End If
    End Sub

    Private Sub txtSalary_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtSalary.KeyPress

        FormHelper.AllowDecimalOnly(e, txtSalary)
    End Sub


End Class