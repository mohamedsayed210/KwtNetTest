﻿Public Class FrmDepartment
    Private currentDepartId As Integer = 0
    Private _departmentService As IDepartmentService
    Public Sub New()
        InitializeComponent()

        _departmentService = New DepartmentService()
    End Sub
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim departmentName As String = txtDepartName.Text.Trim()
        If String.IsNullOrEmpty(departmentName) Then

            MessageBox.Show("Please enter a department name.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If
        Dim newDepartment As New Departments() With {
            .Depart_Name = departmentName,
            .Depart_Location = txtDepartLocation.Text.Trim(),
            .Depart_Manager = txtDepartManager.Text.Trim()
        }
        _departmentService.Add(newDepartment)
        MessageHelper.ShowSuccess("Department added successfully.")
        LoadDepartments()
        ClearInputs()
    End Sub

    Private Sub ClearInputs()
        FormHelper.ClearTextBoxes(Me)
    End Sub

    Private Sub LoadDepartments()


        dgvDepartments.DataSource = _departmentService.GetAll()
        If dgvDepartments.Columns.Contains("Employees") Then
            dgvDepartments.Columns("Employees").Visible = False
        End If
        dgvDepartments.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells)
    End Sub

    Private Sub FrmDepartment_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadDepartments()
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If currentDepartId = 0 Then
            MessageBox.Show("Please select a department to update.", "Selection Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Dim departmentToUpdate = _departmentService.GetById(currentDepartId)
        If departmentToUpdate IsNot Nothing Then
            departmentToUpdate.Depart_Name = txtDepartName.Text.Trim()
            departmentToUpdate.Depart_Location = txtDepartLocation.Text.Trim()
            departmentToUpdate.Depart_Manager = txtDepartManager.Text.Trim()
            _departmentService.Update(departmentToUpdate)
            MessageHelper.ShowSuccess("Department added successfully.")

            LoadDepartments()
            ClearInputs()
            currentDepartId = 0
        Else
            MessageHelper.ShowError("Department not found.")
        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If currentDepartId = 0 Then
            MessageBox.Show("Please select a department to delete.", "Selection Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Dim departmentToDelete = _departmentService.GetById(currentDepartId)
        If departmentToDelete IsNot Nothing Then
            _departmentService.Delete(currentDepartId)
            MessageBox.Show("Department deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            LoadDepartments()
            ClearInputs()
            currentDepartId = 0
        Else
            MessageHelper.ShowError("Department not found.")

        End If
    End Sub
    Private Sub dgvDepartments_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvDepartments.CellClick
        If e.RowIndex >= 0 Then
            Dim selectedRow As DataGridViewRow = dgvDepartments.Rows(e.RowIndex)
            currentDepartId = Convert.ToInt32(selectedRow.Cells("Depart_Id").Value)
            txtDepartName.Text = selectedRow.Cells("Depart_Name").Value.ToString()
            txtDepartLocation.Text = selectedRow.Cells("Depart_Location").Value.ToString()
            txtDepartManager.Text = selectedRow.Cells("Depart_Manager").Value.ToString()
        End If
    End Sub

End Class