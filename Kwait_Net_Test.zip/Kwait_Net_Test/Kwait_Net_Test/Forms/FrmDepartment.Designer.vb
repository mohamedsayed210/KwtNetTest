﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmDepartment
    Inherits System.Windows.Forms.Form

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        txtDepartName = New TextBox()
        txtDepartLocation = New TextBox()
        txtDepartManager = New TextBox()
        btnAdd = New Button()
        btnUpdate = New Button()
        btnDelete = New Button()
        dgvDepartments = New DataGridView()
        CType(dgvDepartments, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(30, 30)
        Label1.Name = "Label1"
        Label1.Size = New Size(150, 19)
        Label1.TabIndex = 0
        Label1.Text = "Department Name"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(30, 70)
        Label2.Name = "Label2"
        Label2.Size = New Size(77, 19)
        Label2.TabIndex = 1
        Label2.Text = "Location"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(30, 110)
        Label3.Name = "Label3"
        Label3.Size = New Size(76, 19)
        Label3.TabIndex = 2
        Label3.Text = "Manager"
        ' 
        ' txtDepartName
        ' 
        txtDepartName.Location = New Point(186, 30)
        txtDepartName.Name = "txtDepartName"
        txtDepartName.Size = New Size(200, 27)
        txtDepartName.TabIndex = 3
        ' 
        ' txtDepartLocation
        ' 
        txtDepartLocation.Location = New Point(186, 70)
        txtDepartLocation.Name = "txtDepartLocation"
        txtDepartLocation.Size = New Size(200, 27)
        txtDepartLocation.TabIndex = 4
        ' 
        ' txtDepartManager
        ' 
        txtDepartManager.Location = New Point(186, 110)
        txtDepartManager.Name = "txtDepartManager"
        txtDepartManager.Size = New Size(200, 27)
        txtDepartManager.TabIndex = 5
        ' 
        ' btnAdd
        ' 
        btnAdd.Location = New Point(400, 27)
        btnAdd.Name = "btnAdd"
        btnAdd.Size = New Size(100, 30)
        btnAdd.TabIndex = 6
        btnAdd.Text = "Add"
        ' 
        ' btnUpdate
        ' 
        btnUpdate.Location = New Point(400, 67)
        btnUpdate.Name = "btnUpdate"
        btnUpdate.Size = New Size(100, 30)
        btnUpdate.TabIndex = 7
        btnUpdate.Text = "Update"
        ' 
        ' btnDelete
        ' 
        btnDelete.Location = New Point(400, 107)
        btnDelete.Name = "btnDelete"
        btnDelete.Size = New Size(100, 30)
        btnDelete.TabIndex = 8
        btnDelete.Text = "Delete"
        ' 
        ' dgvDepartments
        ' 
        dgvDepartments.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        dgvDepartments.ColumnHeadersHeight = 29
        dgvDepartments.Location = New Point(30, 160)
        dgvDepartments.MultiSelect = False
        dgvDepartments.Name = "dgvDepartments"
        dgvDepartments.ReadOnly = True
        dgvDepartments.RowHeadersWidth = 51
        dgvDepartments.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgvDepartments.Size = New Size(600, 250)
        dgvDepartments.TabIndex = 9
        ' 
        ' FrmDepartment
        ' 
        BackColor = Color.FromArgb(CByte(243), CByte(240), CByte(240))
        ClientSize = New Size(680, 450)
        Controls.Add(Label1)
        Controls.Add(Label2)
        Controls.Add(Label3)
        Controls.Add(txtDepartName)
        Controls.Add(txtDepartLocation)
        Controls.Add(txtDepartManager)
        Controls.Add(btnAdd)
        Controls.Add(btnUpdate)
        Controls.Add(btnDelete)
        Controls.Add(dgvDepartments)
        Font = New Font("Arial", 10F, FontStyle.Bold)
        Name = "FrmDepartment"
        Text = "Departments"
        CType(dgvDepartments, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtDepartName As TextBox
    Friend WithEvents txtDepartLocation As TextBox
    Friend WithEvents txtDepartManager As TextBox
    Friend WithEvents btnAdd As Button
    Friend WithEvents btnUpdate As Button
    Friend WithEvents btnDelete As Button
    Friend WithEvents dgvDepartments As DataGridView
End Class
