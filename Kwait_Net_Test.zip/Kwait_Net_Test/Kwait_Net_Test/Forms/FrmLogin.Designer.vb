﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmLogin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        lblTitle = New Label()
        lblUsername = New Label()
        lblPassword = New Label()
        txtUsername = New TextBox()
        txtPassword = New TextBox()
        chkShowPass = New CheckBox()
        btnLogin = New Button()
        btnCancel = New Button()
        SuspendLayout()
        ' 
        ' lblTitle
        ' 
        lblTitle.AutoSize = True
        lblTitle.Font = New Font("Segoe UI", 18F, FontStyle.Bold)
        lblTitle.Location = New Point(90, 20)
        lblTitle.Name = "lblTitle"
        lblTitle.Size = New Size(263, 41)
        lblTitle.TabIndex = 0
        lblTitle.Text = "Employee System"
        lblTitle.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' lblUsername
        ' 
        lblUsername.AutoSize = True
        lblUsername.Font = New Font("Segoe UI", 10F)
        lblUsername.Location = New Point(50, 90)
        lblUsername.Name = "lblUsername"
        lblUsername.Size = New Size(91, 23)
        lblUsername.TabIndex = 1
        lblUsername.Text = "Username:"
        ' 
        ' lblPassword
        ' 
        lblPassword.AutoSize = True
        lblPassword.Font = New Font("Segoe UI", 10F)
        lblPassword.Location = New Point(50, 130)
        lblPassword.Name = "lblPassword"
        lblPassword.Size = New Size(84, 23)
        lblPassword.TabIndex = 3
        lblPassword.Text = "Password:"
        ' 
        ' txtUsername
        ' 
        txtUsername.Font = New Font("Segoe UI", 10F)
        txtUsername.Location = New Point(150, 87)
        txtUsername.Name = "txtUsername"
        txtUsername.Size = New Size(200, 30)
        txtUsername.TabIndex = 2
        ' 
        ' txtPassword
        ' 
        txtPassword.Font = New Font("Segoe UI", 10F)
        txtPassword.Location = New Point(150, 127)
        txtPassword.Name = "txtPassword"
        txtPassword.Size = New Size(200, 30)
        txtPassword.TabIndex = 4
        txtPassword.UseSystemPasswordChar = True
        ' 
        ' chkShowPass
        ' 
        chkShowPass.AutoSize = True
        chkShowPass.Font = New Font("Segoe UI", 9F)
        chkShowPass.Location = New Point(150, 163)
        chkShowPass.Name = "chkShowPass"
        chkShowPass.Size = New Size(132, 24)
        chkShowPass.TabIndex = 5
        chkShowPass.Text = "Show Password"
        chkShowPass.UseVisualStyleBackColor = True
        ' 
        ' btnLogin
        ' 
        btnLogin.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        btnLogin.Location = New Point(150, 200)
        btnLogin.Name = "btnLogin"
        btnLogin.Size = New Size(90, 40)
        btnLogin.TabIndex = 6
        btnLogin.Text = "Login"
        btnLogin.UseVisualStyleBackColor = True
        ' 
        ' btnCancel
        ' 
        btnCancel.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        btnCancel.Location = New Point(260, 200)
        btnCancel.Name = "btnCancel"
        btnCancel.Size = New Size(90, 40)
        btnCancel.TabIndex = 7
        btnCancel.Text = "Cancel"
        btnCancel.UseVisualStyleBackColor = True
        ' 
        ' FrmLogin
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(420, 270)
        Controls.Add(btnCancel)
        Controls.Add(btnLogin)
        Controls.Add(chkShowPass)
        Controls.Add(txtPassword)
        Controls.Add(lblPassword)
        Controls.Add(txtUsername)
        Controls.Add(lblUsername)
        Controls.Add(lblTitle)
        FormBorderStyle = FormBorderStyle.FixedDialog
        MaximizeBox = False
        MinimizeBox = False
        Name = "FrmLogin"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Login"
        ResumeLayout(False)
        PerformLayout()

    End Sub

    Friend WithEvents lblTitle As Label
    Friend WithEvents lblUsername As Label
    Friend WithEvents lblPassword As Label
    Friend WithEvents txtUsername As TextBox
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents chkShowPass As CheckBox
    Friend WithEvents btnLogin As Button
    Friend WithEvents btnCancel As Button
End Class
