﻿Public Class LeaveService
    Implements ILeaveService

    Public Function GetByEmployee(empId As Integer) As List(Of LeavesDisplayDto) Implements ILeaveService.GetByEmployee

        Using ctx As New EmployeeContext()
            Dim leaves = ctx.Leaves.
                     Where(Function(l) l.EmployeeID = empId).
                     Select(Function(l) New LeavesDisplayDto With {
                         .LeaveID = l.LeaveID,
                         .EmployeeID = l.EmployeeID,
                         .EmployeeName = l.Employee.FullName,
                         .LeaveTypeName = l.Empl_LeaveType.LeaveType_Name,
                         .StartDate = l.StartDate.Value,
                         .EndDate = l.EndDate.Value,
                      .Notes = If(l.Notes, ""),
                        .Phone_Number = If(l.Employee.Phone_Number, "")
                     }).ToList()
            Return leaves
        End Using
    End Function

    Public Sub Add(leave As Leaves) Implements ILeaveService.Add
        Using ctx As New EmployeeContext()
            ctx.Leaves.Add(leave)
            ctx.SaveChanges()
        End Using
    End Sub
    Public Sub Update(leave As Leaves) Implements ILeaveService.Update
        Using ctx As New EmployeeContext()
            Dim existingLeave = ctx.Leaves.Find(leave.LeaveID)
            If existingLeave IsNot Nothing Then
                existingLeave.EmployeeID = leave.EmployeeID
                existingLeave.LeaveType_ID = leave.LeaveType_ID
                existingLeave.StartDate = leave.StartDate
                existingLeave.EndDate = leave.EndDate
                existingLeave.Notes = leave.Notes
                ctx.SaveChanges()
            End If
        End Using
    End Sub
    Public Sub Delete(leaveId As Integer) Implements ILeaveService.Delete
        Using ctx As New EmployeeContext()
            Dim lv = ctx.Leaves.Find(leaveId)
            If lv IsNot Nothing Then
                ctx.Leaves.Remove(lv)
                ctx.SaveChanges()
            End If
        End Using
    End Sub
End Class
