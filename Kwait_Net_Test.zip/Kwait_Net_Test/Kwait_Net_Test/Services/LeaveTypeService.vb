﻿Public Class LeaveTypeService
    Implements ILeaveTypeService

    Public Function GetAll() As List(Of LeaveTypes) _
        Implements ILeaveTypeService.GetAll

        Using ctx As New EmployeeContext()
            Return ctx.LeaveTypes.ToList()
        End Using
    End Function

    Public Function GetById(id As Integer) As LeaveTypes _
        Implements ILeaveTypeService.GetById

        Using ctx As New EmployeeContext()
            Return ctx.LeaveTypes.FirstOrDefault(Function(l) l.LeaveTypeId = id)
        End Using
    End Function

    Public Sub Add(leaveType As LeaveTypes) _
        Implements ILeaveTypeService.Add

        Using ctx As New EmployeeContext()
            ctx.LeaveTypes.Add(leaveType)
            ctx.SaveChanges()
        End Using
    End Sub

    Public Sub Update(leaveType As LeaveTypes) _
        Implements ILeaveTypeService.Update

        Using ctx As New EmployeeContext()
            Dim lt = ctx.LeaveTypes.FirstOrDefault(Function(l) l.LeaveTypeId = leaveType.LeaveTypeId)
            If lt IsNot Nothing Then
                lt.LeaveType_Name = leaveType.LeaveType_Name
                ctx.SaveChanges()
            End If
        End Using
    End Sub

    Public Sub Delete(id As Integer) _
        Implements ILeaveTypeService.Delete

        Using ctx As New EmployeeContext()
            Dim lt = ctx.LeaveTypes.FirstOrDefault(Function(l) l.LeaveTypeId = id)
            If lt IsNot Nothing Then
                ctx.LeaveTypes.Remove(lt)
                ctx.SaveChanges()
            End If
        End Using
    End Sub
End Class
