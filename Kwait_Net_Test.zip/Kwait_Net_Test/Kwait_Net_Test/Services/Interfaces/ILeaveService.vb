﻿Public Interface ILeaveService
    Function GetByEmployee(empId As Integer) As List(Of LeavesDisplayDto)
    Sub Add(leave As Leaves)
    Sub Delete(leaveId As Integer)
    Sub Update(leave As Leaves)
End Interface
