﻿Public Interface ILeaveTypeService
    Function GetAll() As List(Of LeaveTypes)
    Function GetById(id As Integer) As LeaveTypes
    Sub Add(leaveType As LeaveTypes)
    Sub Update(leaveType As LeaveTypes)
    Sub Delete(id As Integer)
End Interface
