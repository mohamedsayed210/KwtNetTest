﻿Public Interface IPositionService
    Function GetAll() As List(Of Position)
    Function GetById(id As Integer) As Position
    Sub Add(position As Position)
    Sub Update(position As Position)
    Sub Delete(id As Integer)
End Interface
