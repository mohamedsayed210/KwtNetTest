﻿Public Interface IEmployeeService
    Function GetEmployees() As List(Of Employees)
    Function GetTotalCount() As Integer
    Function GetById(employeeId As Integer) As Employees
    Sub Add(employee As Employees)
    Sub Delete(employeeId As Integer)
    Sub Update(employee As Employees)
End Interface
