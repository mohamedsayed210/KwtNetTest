﻿Public Interface IDepartmentService
    Function GetAll() As List(Of Departments)
    Function GetById(id As Integer) As Departments
    Sub Add(department As Departments)
    Sub Update(department As Departments)
    Sub Delete(id As Integer)
End Interface
