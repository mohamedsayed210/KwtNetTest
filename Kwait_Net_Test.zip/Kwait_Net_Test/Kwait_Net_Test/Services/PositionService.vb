﻿Public Class PositionService
    Implements IPositionService

    Public Function GetAll() As List(Of Position) Implements IPositionService.GetAll
        Using ctx As New EmployeeContext()
            Return ctx.Positions.ToList()
        End Using
    End Function
    Public Function GetById(id As Integer) As Position Implements IPositionService.GetById

        Using ctx As New EmployeeContext()
            Return ctx.Positions.FirstOrDefault(Function(p) p.Position_ID = id)
        End Using
    End Function
    Public Sub Add(position As Position) Implements IPositionService.Add

        Using ctx As New EmployeeContext()
            ctx.Positions.Add(position)
            ctx.SaveChanges()
        End Using
    End Sub
    Public Sub Update(position As Position) Implements IPositionService.Update

        Using ctx As New EmployeeContext()
            Dim pos = ctx.Positions.FirstOrDefault(Function(p) p.Position_ID = position.Position_ID)
            If pos IsNot Nothing Then
                pos.Position_Name = position.Position_Name
                ctx.SaveChanges()
            End If
        End Using
    End Sub

    Public Sub Delete(id As Integer) _
        Implements IPositionService.Delete

        Using ctx As New EmployeeContext()
            Dim pos = ctx.Positions.FirstOrDefault(Function(p) p.Position_ID = id)
            If pos IsNot Nothing Then
                ctx.Positions.Remove(pos)
                ctx.SaveChanges()
            End If
        End Using
    End Sub
End Class
