﻿Public Class EmployeeService
    Implements IEmployeeService

    Public Function GetEmployees() _
        As List(Of Employees) Implements IEmployeeService.GetEmployees

        Using ctx As New EmployeeContext()
            Return ctx.Employees _
            .OrderBy(Function(e) e.EmployeeID).ToList()
        End Using
    End Function
    Public Function GetById(empId As Integer) As Employees _
        Implements IEmployeeService.GetById

        Using ctx As New EmployeeContext()
            Return ctx.Employees.FirstOrDefault(Function(e) e.EmployeeID = empId)
        End Using
    End Function
    Public Function GetTotalCount() As Integer Implements IEmployeeService.GetTotalCount
        Using ctx As New EmployeeContext()
            Return ctx.Employees.Count()
        End Using
    End Function

    Public Sub Add(employee As Employees) Implements IEmployeeService.Add
        Using ctx As New EmployeeContext()
            ctx.Employees.Add(employee)
            ctx.SaveChanges()
        End Using
    End Sub
    Public Sub Update(employee As Employees) Implements IEmployeeService.Update
        Using ctx As New EmployeeContext()
            Dim emp = ctx.Employees.FirstOrDefault(Function(e) e.EmployeeID = employee.EmployeeID)
            If emp IsNot Nothing Then
                emp.FullName = employee.FullName
                emp.HireDate = employee.HireDate
                emp.Dep_Id = employee.Dep_Id
                emp.Position_Id = employee.Position_Id
                emp.Salary = employee.Salary
                emp.Emp_Address = employee.Emp_Address
                emp.Phone_Number = employee.Phone_Number
                ctx.SaveChanges()
            End If
        End Using
    End Sub
    Public Sub Delete(employeeId As Integer) Implements IEmployeeService.Delete
        Using ctx As New EmployeeContext()
            Dim emp = ctx.Employees.FirstOrDefault(Function(e) e.EmployeeID = employeeId)
            If emp IsNot Nothing Then
                ctx.Employees.Remove(emp)
                ctx.SaveChanges()
            End If
        End Using
    End Sub
End Class
