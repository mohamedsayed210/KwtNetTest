﻿Public Class DepartmentService
    Implements IDepartmentService
    Public Function GetAll() As List(Of Departments) _
        Implements IDepartmentService.GetAll

        Using ctx As New EmployeeContext()
            Return ctx.Departments.ToList()
        End Using
    End Function

    Public Function GetById(id As Integer) As Departments _
        Implements IDepartmentService.GetById

        Using ctx As New EmployeeContext()
            Return ctx.Departments.FirstOrDefault(Function(d) d.Depart_Id = id)
        End Using
    End Function

    Public Sub Add(department As Departments) _
        Implements IDepartmentService.Add

        Using ctx As New EmployeeContext()
            ctx.Departments.Add(department)
            ctx.SaveChanges()
        End Using
    End Sub

    Public Sub Update(department As Departments) Implements IDepartmentService.Update

        Using ctx As New EmployeeContext()
            Dim dept = ctx.Departments.FirstOrDefault(Function(d) d.Depart_Id = department.Depart_Id)
            If dept IsNot Nothing Then
                dept.Depart_Name = department.Depart_Name
                dept.Depart_Location = department.Depart_Location
                dept.Depart_Manager = department.Depart_Manager
                ctx.SaveChanges()
            End If
        End Using
    End Sub

    Public Sub Delete(id As Integer) Implements IDepartmentService.Delete

        Using ctx As New EmployeeContext()
            Dim dept = ctx.Departments.FirstOrDefault(Function(d) d.Depart_Id = id)
            If dept IsNot Nothing Then
                ctx.Departments.Remove(dept)
                ctx.SaveChanges()
            End If
        End Using
    End Sub
End Class

