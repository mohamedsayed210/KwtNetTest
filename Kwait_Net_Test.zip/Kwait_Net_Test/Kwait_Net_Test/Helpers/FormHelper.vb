﻿Imports Windows.Win32.UI

Public Class FormHelper
    Public Shared Sub ClearTextBoxes(parent As Control)
        For Each ctrl As Control In parent.Controls

            If TypeOf ctrl Is TextBox Then
                CType(ctrl, TextBox).Clear()


            ElseIf TypeOf ctrl Is ComboBox Then
                CType(ctrl, ComboBox).SelectedIndex = -1

            ElseIf TypeOf ctrl Is DateTimePicker Then
                CType(ctrl, DateTimePicker).Value = Date.Today


            ElseIf TypeOf ctrl Is CheckBox Then
                CType(ctrl, CheckBox).Checked = False


            ElseIf TypeOf ctrl Is RadioButton Then
                CType(ctrl, RadioButton).Checked = False

            End If

            If ctrl.HasChildren Then
                ClearTextBoxes(ctrl)
            End If
        Next
    End Sub

    Public Shared Sub AllowDecimalOnly(e As KeyPressEventArgs, txt As TextBox)

        If Char.IsControl(e.KeyChar) Then
            Return
        End If

        If Char.IsDigit(e.KeyChar) Then
            Return
        End If

        If e.KeyChar = "."c AndAlso Not txt.Text.Contains(".") Then
            Return
        End If

        e.Handled = True
    End Sub
End Class
