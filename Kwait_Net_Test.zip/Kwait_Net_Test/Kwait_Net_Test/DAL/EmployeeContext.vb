﻿Imports System.Reflection.Emit
Imports Microsoft.VisualBasic.ApplicationServices
Imports Microsoft.EntityFrameworkCore

Public Class EmployeeContext
    Inherits DbContext

    Public Property Employees As DbSet(Of Employees)
    Public Property Departments As DbSet(Of Departments)
    Public Property Positions As DbSet(Of Position)
    Public Property Leaves As DbSet(Of Leaves)
    Public Property LeaveTypes As DbSet(Of LeaveTypes)
    Public Property Users As DbSet(Of Users)

    Protected Overrides Sub OnConfiguring(optionsBuilder As DbContextOptionsBuilder)

        optionsBuilder.UseSqlServer("Server=(localdb)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\DataBase\EmployeeDB.mdf;Database=EmployeeDB;Trusted_Connection=True;")
    End Sub

    Protected Overrides Sub OnModelCreating(modelBuilder As ModelBuilder)
        ' Configure primary keys
        modelBuilder.Entity(Of Departments)().HasKey(Function(d) d.Depart_Id)
        modelBuilder.Entity(Of Position)().HasKey(Function(p) p.Position_ID)
        modelBuilder.Entity(Of Employees)().HasKey(Function(e) e.EmployeeID)
        modelBuilder.Entity(Of LeaveTypes)().HasKey(Function(l) l.LeaveTypeId)
        modelBuilder.Entity(Of Leaves)().HasKey(Function(l) l.LeaveID)
        modelBuilder.Entity(Of Users)().HasKey(Function(u) u.UserID)


        modelBuilder.Entity(Of Employees)() _
            .HasOne(Function(e) e.Department) _
            .WithMany(Function(d) d.Employees) _
            .HasForeignKey(Function(e) e.Dep_Id)

        modelBuilder.Entity(Of Employees)() _
            .HasOne(Function(e) e.Position) _
            .WithMany(Function(p) p.Employees) _
            .HasForeignKey(Function(e) e.Position_Id)

        modelBuilder.Entity(Of Leaves)() _
            .HasOne(Function(l) l.Employee) _
            .WithMany(Function(e) e.Leaves) _
            .HasForeignKey(Function(l) l.EmployeeID)

        modelBuilder.Entity(Of Leaves)() _
            .HasOne(Function(l) l.Empl_LeaveType) _
            .WithMany(Function(lt) lt.Leaves) _
        '   .HasForeignKey(Function(l) l.LeaveType)
    End Sub
End Class
