﻿Imports System.Data.OleDb
Imports System.Configuration
Public Class DbConnection

    Public Shared Function GetConnection() As OleDbConnection
        Dim connStr As String = ConfigurationManager.ConnectionStrings("AccessDB").ConnectionString
        Return New OleDbConnection(connStr)
    End Function
End Class
