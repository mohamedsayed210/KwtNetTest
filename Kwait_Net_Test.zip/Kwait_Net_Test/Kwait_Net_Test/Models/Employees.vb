﻿Public Class Employees
    Public Property EmployeeID As Integer
    Public Property FullName As String
    Public Property HireDate As Date
    Public Property Dep_Id As Integer?
    Public Property Position_Id As Integer?
    Public Property Salary As Decimal?
    Public Property Phone_Number As String = String.Empty
    Property Emp_Address As String = String.Empty

    Public Overridable Property Department As Departments
    Public Overridable Property Position As Position
    Public Overridable Property Leaves As ICollection(Of Leaves)
End Class
