﻿Public Class Position
    Public Property Position_ID As Integer
    Public Property Position_Name As String

    Public Overridable Property Employees As ICollection(Of Employees)
End Class
