﻿Public Class Users
    Public Property UserID As Integer
    Public Property UserName As String
    Public Property Password As String
    Public Property Email As String
    Public Property Role As String
End Class
