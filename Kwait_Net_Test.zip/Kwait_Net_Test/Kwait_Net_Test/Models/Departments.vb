﻿Public Class Departments

    Public Property Depart_Id As Integer
    Public Property Depart_Name As String
    Public Property Depart_Location As String
    Public Property Depart_Manager As String

    Public Overridable Property Employees As ICollection(Of Employees)

End Class
