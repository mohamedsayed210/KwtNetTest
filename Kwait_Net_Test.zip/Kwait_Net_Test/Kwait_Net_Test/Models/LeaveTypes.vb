﻿Public Class LeaveTypes
    Public Property LeaveTypeId As Integer
    Public Property LeaveType_Name As String

    Public Overridable Property Leaves As ICollection(Of Leaves)
End Class
