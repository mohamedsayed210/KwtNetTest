﻿Imports System.ComponentModel.DataAnnotations.Schema

Public Class Leaves
    Public Property LeaveID As Integer
    Public Property EmployeeID As Integer?
    Public Property LeaveType_ID As Integer?
    Public Property StartDate As Date?
    Public Property EndDate As Date?
    Public Property Notes As String = String.Empty
    Public Overridable Property Employee As Employees
    <ForeignKey("LeaveType_ID")>
    Public Overridable Property Empl_LeaveType As LeaveTypes
End Class
