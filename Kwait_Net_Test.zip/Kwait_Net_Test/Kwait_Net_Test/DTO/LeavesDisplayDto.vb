﻿Public Class LeavesDisplayDto
    Public Property LeaveID As Integer
    Public Property EmployeeID As Integer
    Public Property EmployeeName As String
    Public Property LeaveTypeName As String
    Public Property StartDate As Date
    Public Property EndDate As Date
    Public Property Notes As String
    Public Property Phone_Number As String
End Class
